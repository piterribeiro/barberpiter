// importa a classe Sequelize
import { Sequelize } from "sequelize";

// Cria uma nova instância de conexão com o banco de dados
const db = new Sequelize(
    "banco", // nome do banco 
    "root", // Usuário administrador do banco
    "",     // senha do banco
    {
        host: "localhost", // onde o banco está
        dialect: "mysql", // o drive do tipo do banco
    }
);

db.authenticate().then((function(){
    console.log("Conectado ao banco com sucesso")
})).catch(function(erro){
    console.log("Erro ao conectar ao banco de dados" + erro)
});

export default db;

  


